#include "Elemento.h"

Elemento::Elemento(Mesh* modelo): _modelo(modelo), _siguiente(NULL)
{
}
