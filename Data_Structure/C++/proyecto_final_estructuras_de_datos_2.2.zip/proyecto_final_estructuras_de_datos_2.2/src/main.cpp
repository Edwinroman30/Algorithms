#include "../motor_grafico/motor_grafico.h"
#include "Lista.h"
#include <iostream>

using namespace std;

int main()
{
    printf("Iniciando proyecto final de Estructuras de datos en ITLA\n");
    return iniciar();
}
